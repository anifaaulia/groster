<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class UserSeeder extends Seeder
{
    public function run(): void
    {
        $institution = \App\Models\Institution::first();
        $institutionId = $institution ? $institution->id : null;

        // Admin Sistem
        $admin = User::create([
            'name'           => 'Admin Sistem',
            'email'          => 'admin@groster.com',
            'password'       => Hash::make('password'),
            'institution_id' => $institutionId,
        ]);
        $admin->assignRole('admin');

        // PIC (Person In Charge)
        $pic = User::create([
            'name'           => 'PIC G-Roster',
            'email'          => 'pic@groster.com',
            'password'       => Hash::make('password'),
            'institution_id' => $institutionId,
        ]);
        $pic->assignRole('pic');

        // Participant
        $participant = User::create([
            'name'           => 'Peserta Groster',
            'email'          => 'user@groster.com',
            'password'       => Hash::make('password'),
            'institution_id' => $institutionId,
        ]);
        $participant->assignRole('participant');
    }
}
